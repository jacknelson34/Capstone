using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices.ObjectiveC;
using System.Windows.Forms;

namespace WinFormsDemo2
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.Timer colorTimer;
        private Label colorfulLabel;
        private Random random;
        private Button changeColorButton;

        public Form1()
        {
            // Initialize form properties
            this.Text = "Winforms Demo : Colors";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Initialize label
            colorfulLabel = new Label();
            colorfulLabel.Text = "Winforms Demo: Color Testing";
            colorfulLabel.Font = new Font("Times New Roman", 24, FontStyle.Bold);
            colorfulLabel.AutoSize = true;
            colorfulLabel.Location = new Point(this.ClientSize.Width / 2 - colorfulLabel.Width / 2, this.ClientSize.Height / 2 - colorfulLabel.Height / 2);
            this.Controls.Add(colorfulLabel);

            // Initialize random
            random = new Random();

            // Create a button to change background color randomly
            changeColorButton = new Button();
            changeColorButton.Text = "Randomize Colors";
            changeColorButton.Font = new Font("Times New Roman", 12, FontStyle.Bold);
            changeColorButton.Size = new Size(200, 50);
            changeColorButton.Location = new Point(this.ClientSize.Width / 2 - changeColorButton.Width / 2, this.ClientSize.Height - 80);
            changeColorButton.Click += ChangeColorButton_Click;
            this.Controls.Add(changeColorButton);

            // Set up the timer to change the label color
            colorTimer = new System.Windows.Forms.Timer();
            colorTimer.Interval = 50000; // 50000 ms
            colorTimer.Tick += ColorTimer_Tick;
            colorTimer.Start();

            // Subscribe to the Paint event for a gradient background
            this.Paint += Form1_Paint;

            // Center Controls
            CenterControls();
            this.Resize += Form1_Resize;
        }

        // Handler for form resize
        private void Form1_Resize(object sender, EventArgs e)
        {
            CenterControls();
        }

        // Method to Center Title/Controls
        private void CenterControls()
        {

            // Center Label
            colorfulLabel.Location = new Point(
                (this.ClientSize.Width / 2) - (colorfulLabel.Width / 2),
                this.ClientSize.Height / 4);

            // Center Button
            changeColorButton.Location = new Point(
                (this.ClientSize.Width / 2) - (changeColorButton.Width / 2),
                this.ClientSize.Height - 100);
        }

        // Paint gradient background
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, Color.FromArgb(random.Next(256), random.Next(256), random.Next(256)), Color.FromArgb(random.Next(256), random.Next(256), random.Next(256)), 45F))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        // Change the label's color every tick
        private void ColorTimer_Tick(object sender, EventArgs e)
        {
            colorfulLabel.ForeColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
            this.Invalidate(); // Forces repainting the gradient
        }

        // Change the background to a random color when button is clicked
        private void ChangeColorButton_Click(object sender, EventArgs e)
        {
            this.Invalidate(); // Forces repainting the gradient
        }

        // Main entry point
        /*[STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }*/
    }
}